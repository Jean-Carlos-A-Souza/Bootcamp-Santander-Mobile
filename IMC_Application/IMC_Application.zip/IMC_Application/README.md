# Bootcamp-Santander-Mobile

1 - Primeiro Aplicativo Android Usando Kotlin
-------------------------------------------------------------------------------------------------------------------------------
    Este é um aplicativo simples para calculo de IMC, aonde o usuario ira informar seu peso e altura, e o aplicativo ira retorna o valor e seu indice corporal.

